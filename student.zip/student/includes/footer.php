    </main>
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Vipulananda Central College. All Rights Reserved.</p>
            <p>Develop for Academic Purpose.</p>
        </div>
    </footer>
    <script src="<?php echo $prefix; ?>assets/js/script.js"></script>
</body>
</html>
