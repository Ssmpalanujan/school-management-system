package com.example.studentdirectory;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.studentdirectory.db.DatabaseHelper;
import com.google.android.material.textfield.TextInputEditText;

public class AdminAddTeacherActivity extends AppCompatActivity {

    private TextInputEditText etName, etPhone, etEmail, etSubjects, etQualification, etBio, etUsername, etPassword;
    private Button btnSave;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_add_teacher);

        dbHelper = new DatabaseHelper(this);

        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        etEmail = findViewById(R.id.etEmail);
        etSubjects = findViewById(R.id.etSubjects);
        etQualification = findViewById(R.id.etQualification);
        etBio = findViewById(R.id.etBio);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnSave = findViewById(R.id.btnSave);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTeacher();
            }
        });
    }

    private void saveTeacher() {
        String name = etName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String subjects = etSubjects.getText().toString().trim();
        String qualification = etQualification.getText().toString().trim();
        String bio = etBio.getText().toString().trim();
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill in all required fields (Name, Username, Password)", Toast.LENGTH_SHORT)
                    .show();
            return;
        }

        boolean success = dbHelper.addTeacher(name, username, password, subjects, qualification, bio, phone, email);
        if (success) {
            Toast.makeText(this, "Teacher added successfully!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to add teacher. Username might already exist.", Toast.LENGTH_SHORT).show();
        }
    }
}
