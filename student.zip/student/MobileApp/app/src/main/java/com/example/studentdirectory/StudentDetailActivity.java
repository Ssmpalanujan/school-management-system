package com.example.studentdirectory;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.studentdirectory.db.DatabaseHelper;

public class StudentDetailActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private int studentId;

    private TextView tvName, tvGender, tvGrade, tvAdmission, tvParent, tvAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_detail);

        dbHelper = new DatabaseHelper(this);
        studentId = getIntent().getIntExtra("student_id", -1);

        tvName = findViewById(R.id.tvDetailName);
        tvGender = findViewById(R.id.tvDetailGender);
        tvGrade = findViewById(R.id.tvDetailGrade);
        tvAdmission = findViewById(R.id.tvDetailAdmission);
        tvParent = findViewById(R.id.tvDetailParent);
        tvAddress = findViewById(R.id.tvDetailAddress);

        if (studentId != -1) {
            loadStudentDetails();
        } else {
            Toast.makeText(this, "Error loading student.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void loadStudentDetails() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_STUDENTS, null,
                DatabaseHelper.COL_STUDENT_ID + "=?", new String[] { String.valueOf(studentId) },
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            tvName.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_FULL_NAME_STUDENT)));
            tvGender.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_GENDER)));

            String grade = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_GRADE));
            String cls = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_CLASS));
            tvGrade.setText("Grade: " + grade + "-" + cls);

            tvAdmission.setText(
                    "Admission No: " + cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ADMISSION_NO)));
            tvParent.setText(
                    "Parent: " + cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_PARENT_NAME)));
            tvAddress.setText("Address: " + cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ADDRESS)));

            cursor.close();
        }
    }
}
