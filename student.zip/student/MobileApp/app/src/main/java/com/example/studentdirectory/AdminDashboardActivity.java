package com.example.studentdirectory;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AdminDashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        TextView tvWelcome = findViewById(R.id.tvWelcome);
        Button btnLogout = findViewById(R.id.btnLogout);

        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        String fullName = prefs.getString("full_name", "User");
        tvWelcome.setText("Welcome, " + fullName);

        androidx.cardview.widget.CardView btnManageTeachers = findViewById(R.id.btnManageTeachers);
        btnManageTeachers.setOnClickListener(v -> {
            startActivity(new Intent(this, AdminTeacherListActivity.class));
        });

        // Assuming Manage Students is just a placeholder for now as per previous state,
        // but if it has an ID now, I should perhaps handle it too or leave it.
        // The user didn't explicitly ask to fix Manage Students, just link Teacher
        // Management.

        btnLogout.setOnClickListener(v -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear();
            editor.apply();

            startActivity(new Intent(this, PublicDirectoryActivity.class));
            finish();
        });
    }
}
