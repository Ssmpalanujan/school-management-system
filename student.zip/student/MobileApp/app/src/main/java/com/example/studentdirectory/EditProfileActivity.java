package com.example.studentdirectory;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.studentdirectory.db.DatabaseHelper;
import com.example.studentdirectory.models.Teacher;
import com.google.android.material.textfield.TextInputEditText;

public class EditProfileActivity extends AppCompatActivity {

    private TextInputEditText etName, etSubjects, etQualification, etBio, etPhone, etEmail;
    private Button btnUpdate;
    private DatabaseHelper dbHelper;
    private int userId;
    private Teacher currentTeacher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        dbHelper = new DatabaseHelper(this);

        etName = findViewById(R.id.etEditName);
        etSubjects = findViewById(R.id.etEditSubjects);
        etQualification = findViewById(R.id.etEditQualification);
        etBio = findViewById(R.id.etEditBio);
        etPhone = findViewById(R.id.etEditPhone);
        etEmail = findViewById(R.id.etEditEmail);
        btnUpdate = findViewById(R.id.btnUpdateProfile);

        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        userId = prefs.getInt("user_id", -1);

        if (userId != -1) {
            loadProfile();
        } else {
            Toast.makeText(this, "Session Error", Toast.LENGTH_SHORT).show();
            finish();
        }

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateProfile();
            }
        });
    }

    private void loadProfile() {
        // Need a method to get Teacher by USER ID, not Teacher ID.
        // I have getTeacherById (teacherID).
        // I need `getTeacherByUserId`.
        // I will implement a quick helper here or add to DB.
        // Adding to DB is better but for speed I'll just check `getAllTeachers` and
        // filter (inefficient but works for small app).
        // Or better: update `getTeacherById` to be generic or add `getTeacherByUserId`.

        // Let's iterate for now since app is small.
        for (Teacher t : dbHelper.getAllTeachers()) {
            if (t.getUserId() == userId) {
                currentTeacher = t;
                break;
            }
        }

        if (currentTeacher != null) {
            etName.setText(currentTeacher.getName());
            etSubjects.setText(currentTeacher.getSubjects());
            etQualification.setText(currentTeacher.getQualification());
            etBio.setText(currentTeacher.getBio());
            etPhone.setText(currentTeacher.getContactNumber());
            etEmail.setText(currentTeacher.getEmail());
        }
    }

    private void updateProfile() {
        if (currentTeacher == null)
            return;

        currentTeacher.setName(etName.getText().toString().trim());
        currentTeacher.setSubjects(etSubjects.getText().toString().trim());
        currentTeacher.setQualification(etQualification.getText().toString().trim());
        currentTeacher.setBio(etBio.getText().toString().trim());
        currentTeacher.setContactNumber(etPhone.getText().toString().trim());
        currentTeacher.setEmail(etEmail.getText().toString().trim());

        boolean success = dbHelper.updateTeacher(currentTeacher);
        if (success) {
            Toast.makeText(this, "Profile Updated Successfully", Toast.LENGTH_SHORT).show();

            // Update Session Name if changed
            SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("full_name", currentTeacher.getName());
            editor.apply();

            finish();
        } else {
            Toast.makeText(this, "Update Failed", Toast.LENGTH_SHORT).show();
        }
    }
}
