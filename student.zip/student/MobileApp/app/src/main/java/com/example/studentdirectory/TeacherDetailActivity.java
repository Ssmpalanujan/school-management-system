package com.example.studentdirectory;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.studentdirectory.db.DatabaseHelper;
import com.example.studentdirectory.models.Teacher;

public class TeacherDetailActivity extends AppCompatActivity {

    private TextView tvName, tvSubjects, tvQualification, tvBio, tvEmail, tvPhone;
    private Button btnMessageTeacher;
    private DatabaseHelper dbHelper;
    private int teacherId;
    private boolean isAdmin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_detail);

        dbHelper = new DatabaseHelper(this);

        tvName = findViewById(R.id.tvDetailName);
        tvSubjects = findViewById(R.id.tvDetailSubjects);
        tvQualification = findViewById(R.id.tvDetailQualification);
        tvBio = findViewById(R.id.tvDetailBio);
        tvEmail = findViewById(R.id.tvDetailEmail);
        tvPhone = findViewById(R.id.tvDetailPhone);
        btnMessageTeacher = findViewById(R.id.btnMessageTeacher);

        teacherId = getIntent().getIntExtra("teacher_id", -1);
        isAdmin = getIntent().getBooleanExtra("is_admin", false);

        if (teacherId != -1) {
            loadTeacherDetails(teacherId);
        } else {
            Toast.makeText(this, "Error loading teacher details", Toast.LENGTH_SHORT).show();
            finish();
        }

        if (isAdmin) {
            btnMessageTeacher.setVisibility(View.GONE); // Admin doesn't message teachers this way usually, or maybe
                                                        // "Edit" instead
            // Could change text to "Edit Teacher"
            btnMessageTeacher.setText("Edit Teacher (Coming Soon)");
            btnMessageTeacher.setVisibility(View.VISIBLE);
        } else {
            btnMessageTeacher.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(TeacherDetailActivity.this, ChatActivity.class);
                    intent.putExtra("receiver_id", dbHelper.getTeacherById(teacherId).getUserId()); // Message needs
                                                                                                    // User ID
                    startActivity(intent);
                }
            });
        }
    }

    private void loadTeacherDetails(int id) {
        Teacher teacher = dbHelper.getTeacherById(id);
        if (teacher != null) {
            tvName.setText(teacher.getName());
            tvSubjects.setText(teacher.getSubjects());
            tvQualification.setText(teacher.getQualification());
            tvBio.setText(teacher.getBio());
            tvEmail.setText(teacher.getEmail());
            tvPhone.setText(teacher.getContactNumber());
        }
    }
}
