package com.example.studentdirectory;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.studentdirectory.db.DatabaseHelper;
import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etUsername, etPassword;
    private Button btnLogin;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> login());
    }

    private void login() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, R.string.error_fill_all, Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_USERS, null,
                DatabaseHelper.COL_USERNAME + "=? AND " + DatabaseHelper.COL_PASSWORD + "=?",
                new String[] { username, password }, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            int userId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_USER_ID));
            String role = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ROLE));
            String fullName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_FULL_NAME));

            // Save Session (Simple SharedPreferences)
            SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putInt("user_id", userId);
            editor.putString("username", username);
            editor.putString("role", role);
            editor.putString("full_name", fullName);
            editor.apply();

            Toast.makeText(this, "Welcome " + fullName, Toast.LENGTH_SHORT).show();

            if ("admin".equals(role)) {
                // startActivity(new Intent(this, AdminDashboardActivity.class));
                startActivity(new Intent(this, MainActivity.class));
            } else if ("teacher".equals(role)) {
                // startActivity(new Intent(this, TeacherDashboardActivity.class));
                startActivity(new Intent(this, MainActivity.class));
            } else {
                // Student or others
                // startActivity(new Intent(this, PublicDirectoryActivity.class));
                startActivity(new Intent(this, MainActivity.class));
            }
            finish();
            cursor.close();
        } else {
            Toast.makeText(this, R.string.error_invalid, Toast.LENGTH_SHORT).show();
        }
    }
}
