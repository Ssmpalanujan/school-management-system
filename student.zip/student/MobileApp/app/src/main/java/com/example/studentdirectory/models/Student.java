package com.example.studentdirectory.models;

public class Student {
    private int id;
    private String admissionNo;
    private String nameWithInitials;
    private String fullName;
    private String gender;
    private String grade;
    private String className;
    private String address;
    private String parentName;
    private String parentContact;
    private String status;

    public Student(int id, String admissionNo, String nameWithInitials, String fullName, String gender, String grade,
            String className, String address, String parentName, String parentContact, String status) {
        this.id = id;
        this.admissionNo = admissionNo;
        this.nameWithInitials = nameWithInitials;
        this.fullName = fullName;
        this.gender = gender;
        this.grade = grade;
        this.className = className;
        this.address = address;
        this.parentName = parentName;
        this.parentContact = parentContact;
        this.status = status;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getAdmissionNo() {
        return admissionNo;
    }

    public String getNameWithInitials() {
        return nameWithInitials;
    }

    public String getFullName() {
        return fullName;
    }

    public String getGender() {
        return gender;
    }

    public String getGrade() {
        return grade;
    }

    public String getClassName() {
        return className;
    }

    public String getAddress() {
        return address;
    }

    public String getParentName() {
        return parentName;
    }

    public String getParentContact() {
        return parentContact;
    }

    public String getStatus() {
        return status;
    }
}
