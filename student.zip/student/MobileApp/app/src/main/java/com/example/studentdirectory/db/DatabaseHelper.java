package com.example.studentdirectory.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import com.example.studentdirectory.models.Teacher;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "vipulananda_school.db";
    private static final int DATABASE_VERSION = 1;

    // Teachers Table
    public static final String TABLE_TEACHERS = "teachers";
    public static final String COL_TEACHER_ID = "id";
    public static final String COL_TEACHER_USER_ID = "user_id"; // FK to users table
    public static final String COL_SUBJECTS = "subjects";
    public static final String COL_QUALIFICATION = "qualification";
    public static final String COL_BIO = "bio";
    public static final String COL_TEACHER_PHONE = "phone";
    public static final String COL_TEACHER_EMAIL = "email";

    // Messages Table
    public static final String TABLE_MESSAGES = "messages";
    public static final String COL_MSG_ID = "id";
    public static final String COL_MSG_SENDER_ID = "sender_id";
    public static final String COL_MSG_RECEIVER_ID = "receiver_id";
    public static final String COL_MSG_TEXT = "message_text";
    public static final String COL_MSG_TIMESTAMP = "timestamp";
    public static final String COL_MSG_READ = "is_read";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        String createUsers = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT, " +
                COL_ROLE + " TEXT, " +
                COL_FULL_NAME + " TEXT)";
        db.execSQL(createUsers);

        // Create Students Table
        String createStudents = "CREATE TABLE " + TABLE_STUDENTS + " (" +
                COL_STUDENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ADMISSION_NO + " TEXT UNIQUE, " +
                COL_NAME_INITIALS + " TEXT, " +
                COL_FULL_NAME_STUDENT + " TEXT, " +
                COL_GENDER + " TEXT, " +
                COL_GRADE + " TEXT, " +
                COL_CLASS + " TEXT, " +
                COL_ADDRESS + " TEXT, " +
                COL_PARENT_NAME + " TEXT, " +
                COL_PARENT_CONTACT + " TEXT, " +
                COL_STATUS + " TEXT DEFAULT 'Active')";
        db.execSQL(createStudents);

        // Create Teachers Table
        String createTeachers = "CREATE TABLE " + TABLE_TEACHERS + " (" +
                COL_TEACHER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_TEACHER_USER_ID + " INTEGER, " +
                COL_SUBJECTS + " TEXT, " +
                COL_QUALIFICATION + " TEXT, " +
                COL_BIO + " TEXT, " +
                COL_TEACHER_PHONE + " TEXT, " +
                COL_TEACHER_EMAIL + " TEXT, " +
                "FOREIGN KEY(" + COL_TEACHER_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_ID + "))";
        db.execSQL(createTeachers);

        // Create Messages Table
        String createMessages = "CREATE TABLE " + TABLE_MESSAGES + " (" +
                COL_MSG_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_MSG_SENDER_ID + " INTEGER, " +
                COL_MSG_RECEIVER_ID + " INTEGER, " +
                COL_MSG_TEXT + " TEXT, " +
                COL_MSG_TIMESTAMP + " TEXT, " +
                COL_MSG_READ + " INTEGER DEFAULT 0, " +
                "FOREIGN KEY(" + COL_MSG_SENDER_ID + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_ID + "), " +
                "FOREIGN KEY(" + COL_MSG_RECEIVER_ID + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_ID + "))";
        db.execSQL(createMessages);

        // Seed Data
        seedData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TEACHERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MESSAGES);
        onCreate(db);
    }

    private void seedData(SQLiteDatabase db) {
        // Admin User (password: admin123)
        ContentValues admin = new ContentValues();
        admin.put(COL_USERNAME, "admin");
        admin.put(COL_PASSWORD, "admin123");
        admin.put(COL_ROLE, "admin");
        admin.put(COL_FULL_NAME, "System Administrator");
        db.insert(TABLE_USERS, null, admin);

        // Teacher User 1 (password: teacher1)
        ContentValues teacher1 = new ContentValues();
        teacher1.put(COL_USERNAME, "teacher1");
        teacher1.put(COL_PASSWORD, "teacher1");
        teacher1.put(COL_ROLE, "teacher");
        teacher1.put(COL_FULL_NAME, "Mr. A. Perera");
        long teacher1Id = db.insert(TABLE_USERS, null, teacher1);

        insertTeacherDetails(db, (int) teacher1Id, "Mathematics, Science", "BSc in Mathematics",
                "Experienced Math teacher with 10 years of service.", "0771112222", "aperera@school.lk");

        // Teacher User 2 (password: teacher2)
        ContentValues teacher2 = new ContentValues();
        teacher2.put(COL_USERNAME, "teacher2");
        teacher2.put(COL_PASSWORD, "teacher2");
        teacher2.put(COL_ROLE, "teacher");
        teacher2.put(COL_FULL_NAME, "Ms. K. Silva");
        long teacher2Id = db.insert(TABLE_USERS, null, teacher2);

        insertTeacherDetails(db, (int) teacher2Id, "English, Literature", "BA in English",
                "Passionate about literature and drama.", "0773334444", "ksilva@school.lk");

        // Student User (password: student1) - Usually students might not have login,
        // but for messaging they need one.
        // Assuming the requirement implies students can login to message.
        // Let's create a student user linked to a student record if needed, or just a
        // generic user for now.
        // For simplicity, let's assume the "Student" table is for records, and "Users"
        // table is for login.
        // Let's create a user for a student to test messaging.
        ContentValues studentUser = new ContentValues();
        studentUser.put(COL_USERNAME, "student1");
        studentUser.put(COL_PASSWORD, "student1");
        studentUser.put(COL_ROLE, "student");
        studentUser.put(COL_FULL_NAME, "Anura Perera");
        long studentUserId = db.insert(TABLE_USERS, null, studentUser);

        // Sample Students Records (Directory data)
        insertStudent(db, "2023001", "A. Perera", "Anura Perera", "Male", "10", "A", "Sample Address 1", "Kamal Perera",
                "0771234567");
        insertStudent(db, "2023002", "B. Silva", "Banu Silva", "Female", "10", "B", "Sample Address 2", "Nimal Silva",
                "0777654321");
        insertStudent(db, "2023003", "C. Fernando", "Chathura Fernando", "Male", "11", "A", "Sample Address 3",
                "Sunil Fernando", "0712345678");

        // Sample Message
        insertMessage(db, (int) studentUserId, (int) teacher1Id, "Hello Sir, I have a doubt in Math.",
                "2023-10-27 10:00:00");
    }

    private void insertStudent(SQLiteDatabase db, String admission, String initials, String fullName, String gender,
            String grade, String cls, String addr, String parent, String contact) {
        ContentValues cv = new ContentValues();
        cv.put(COL_ADMISSION_NO, admission);
        cv.put(COL_NAME_INITIALS, initials);
        cv.put(COL_FULL_NAME_STUDENT, fullName);
        cv.put(COL_GENDER, gender);
        cv.put(COL_GRADE, grade);
        cv.put(COL_CLASS, cls);
        cv.put(COL_ADDRESS, addr);
        cv.put(COL_PARENT_NAME, parent);
        cv.put(COL_PARENT_CONTACT, contact);
        cv.put(COL_STATUS, "Active");
        db.insert(TABLE_STUDENTS, null, cv);
    }

    private void insertTeacherDetails(SQLiteDatabase db, int userId, String subjects, String qual, String bio,
            String phone, String email) {
        ContentValues cv = new ContentValues();
        cv.put(COL_TEACHER_USER_ID, userId);
        cv.put(COL_SUBJECTS, subjects);
        cv.put(COL_QUALIFICATION, qual);
        cv.put(COL_BIO, bio);
        cv.put(COL_TEACHER_PHONE, phone);
        cv.put(COL_TEACHER_EMAIL, email);
        db.insert(TABLE_TEACHERS, null, cv);
    }

    private void insertMessage(SQLiteDatabase db, int senderId, int receiverId, String text, String timestamp) {
        ContentValues cv = new ContentValues();
        cv.put(COL_MSG_SENDER_ID, senderId);
        cv.put(COL_MSG_RECEIVER_ID, receiverId);
        cv.put(COL_MSG_TEXT, text);
        cv.put(COL_MSG_TIMESTAMP, timestamp);
        cv.put(COL_MSG_READ, 0);
        db.insert(TABLE_MESSAGES, null, cv);
    }

    // --- Teacher Operations ---

    public List<Teacher> getAllTeachers() {
        List<Teacher> teachers = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT t.*, u." + COL_FULL_NAME + " FROM " + TABLE_TEACHERS + " t " +
                "JOIN " + TABLE_USERS + " u ON t." + COL_TEACHER_USER_ID + " = u." + COL_USER_ID;
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                Teacher teacher = new Teacher();
                teacher.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_TEACHER_ID)));
                teacher.setUserId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_TEACHER_USER_ID)));
                teacher.setName(cursor.getString(cursor.getColumnIndexOrThrow(COL_FULL_NAME)));
                teacher.setSubjects(cursor.getString(cursor.getColumnIndexOrThrow(COL_SUBJECTS)));
                teacher.setQualification(cursor.getString(cursor.getColumnIndexOrThrow(COL_QUALIFICATION)));
                teacher.setBio(cursor.getString(cursor.getColumnIndexOrThrow(COL_BIO)));
                teacher.setContactNumber(cursor.getString(cursor.getColumnIndexOrThrow(COL_TEACHER_PHONE)));
                teacher.setEmail(cursor.getString(cursor.getColumnIndexOrThrow(COL_TEACHER_EMAIL)));
                teachers.add(teacher);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return teachers;
    }

    public Teacher getTeacherById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Teacher teacher = null;
        String query = "SELECT t.*, u." + COL_FULL_NAME + " FROM " + TABLE_TEACHERS + " t " +
                "JOIN " + TABLE_USERS + " u ON t." + COL_TEACHER_USER_ID + " = u." + COL_USER_ID +
                " WHERE t." + COL_TEACHER_ID + " = ?";
        Cursor cursor = db.rawQuery(query, new String[] { String.valueOf(id) });

        if (cursor.moveToFirst()) {
            teacher = new Teacher();
            teacher.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_TEACHER_ID)));
            teacher.setUserId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_TEACHER_USER_ID)));
            teacher.setName(cursor.getString(cursor.getColumnIndexOrThrow(COL_FULL_NAME)));
            teacher.setSubjects(cursor.getString(cursor.getColumnIndexOrThrow(COL_SUBJECTS)));
            teacher.setQualification(cursor.getString(cursor.getColumnIndexOrThrow(COL_QUALIFICATION)));
            teacher.setBio(cursor.getString(cursor.getColumnIndexOrThrow(COL_BIO)));
            teacher.setContactNumber(cursor.getString(cursor.getColumnIndexOrThrow(COL_TEACHER_PHONE)));
            teacher.setEmail(cursor.getString(cursor.getColumnIndexOrThrow(COL_TEACHER_EMAIL)));
        }
        cursor.close();
        return teacher;
    }

    public boolean addTeacher(String name, String username, String password, String subjects, String qualification,
            String bio, String phone, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            // 1. Add User
            ContentValues userValues = new ContentValues();
            userValues.put(COL_USERNAME, username);
            userValues.put(COL_PASSWORD, password);
            userValues.put(COL_ROLE, "teacher");
            userValues.put(COL_FULL_NAME, name);
            long userId = db.insert(TABLE_USERS, null, userValues);

            if (userId == -1) {
                return false; // User insert failed
            }

            // 2. Add Teacher Details
            ContentValues teacherValues = new ContentValues();
            teacherValues.put(COL_TEACHER_USER_ID, userId);
            teacherValues.put(COL_SUBJECTS, subjects);
            teacherValues.put(COL_QUALIFICATION, qualification);
            teacherValues.put(COL_BIO, bio);
            teacherValues.put(COL_TEACHER_PHONE, phone);
            teacherValues.put(COL_TEACHER_EMAIL, email);
            long teacherId = db.insert(TABLE_TEACHERS, null, teacherValues);

            if (teacherId != -1) {
                db.setTransactionSuccessful();
                return true;
            }
        } finally {
            db.endTransaction();
        }
        return false;
    }

    public boolean updateTeacher(Teacher teacher) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_SUBJECTS, teacher.getSubjects());
        cv.put(COL_QUALIFICATION, teacher.getQualification());
        cv.put(COL_BIO, teacher.getBio());
        cv.put(COL_TEACHER_PHONE, teacher.getContactNumber());
        cv.put(COL_TEACHER_EMAIL, teacher.getEmail());

        int rows = db.update(TABLE_TEACHERS, cv, COL_TEACHER_ID + " = ?",
                new String[] { String.valueOf(teacher.getId()) });

        // Update Name in Users table
        ContentValues userCv = new ContentValues();
        userCv.put(COL_FULL_NAME, teacher.getName());
        db.update(TABLE_USERS, userCv, COL_USER_ID + " = ?", new String[] { String.valueOf(teacher.getUserId()) });

        return rows > 0;
    }

    // --- Messaging Operations ---

    public List<Message> getMessages(int user1Id, int user2Id) {
        List<Message> messages = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Select messages where (sender=user1 AND receiver=user2) OR (sender=user2 AND
        // receiver=user1)
        String query = "SELECT * FROM " + TABLE_MESSAGES +
                " WHERE (" + COL_MSG_SENDER_ID + " = ? AND " + COL_MSG_RECEIVER_ID + " = ?) " +
                " OR (" + COL_MSG_SENDER_ID + " = ? AND " + COL_MSG_RECEIVER_ID + " = ?) " +
                " ORDER BY " + COL_MSG_TIMESTAMP + " ASC";

        Cursor cursor = db.rawQuery(query, new String[] {
                String.valueOf(user1Id), String.valueOf(user2Id),
                String.valueOf(user2Id), String.valueOf(user1Id)
        });

        if (cursor.moveToFirst()) {
            do {
                Message msg = new Message();
                msg.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_MSG_ID)));
                msg.setSenderId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_MSG_SENDER_ID)));
                msg.setReceiverId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_MSG_RECEIVER_ID)));
                msg.setMessageText(cursor.getString(cursor.getColumnIndexOrThrow(COL_MSG_TEXT)));
                msg.setTimestamp(cursor.getString(cursor.getColumnIndexOrThrow(COL_MSG_TIMESTAMP)));
                msg.setRead(cursor.getInt(cursor.getColumnIndexOrThrow(COL_MSG_READ)) == 1);
                messages.add(msg);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return messages;
    }

    public void sendMessage(int senderId, int receiverId, String text) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_MSG_SENDER_ID, senderId);
        cv.put(COL_MSG_RECEIVER_ID, receiverId);
        cv.put(COL_MSG_TEXT, text);

        // Simple timestamp format
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
                java.util.Locale.getDefault());
        String currentDateTime = sdf.format(new java.util.Date());
        cv.put(COL_MSG_TIMESTAMP, currentDateTime);

        cv.put(COL_MSG_READ, 0);
        db.insert(TABLE_MESSAGES, null, cv);
    }

    public List<Message> getConversations(int userId) {
        List<Message> conversations = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Complex query to get latest message per conversation pair
        String query = "SELECT m.*, u." + COL_FULL_NAME + " " +
                "FROM " + TABLE_MESSAGES + " m " +
                "JOIN (" +
                "SELECT MAX(" + COL_MSG_ID + ") as id " +
                "FROM " + TABLE_MESSAGES + " " +
                "WHERE " + COL_MSG_SENDER_ID + " = ? OR " + COL_MSG_RECEIVER_ID + " = ? " +
                "GROUP BY CASE WHEN " + COL_MSG_SENDER_ID + " = ? THEN " + COL_MSG_RECEIVER_ID + " ELSE "
                + COL_MSG_SENDER_ID + " END" +
                ") latest ON m." + COL_MSG_ID + " = latest.id " +
                "JOIN " + TABLE_USERS + " u ON u." + COL_USER_ID + " = (CASE WHEN m." + COL_MSG_SENDER_ID
                + " = ? THEN m." + COL_MSG_RECEIVER_ID + " ELSE m." + COL_MSG_SENDER_ID + " END) " +
                "ORDER BY m." + COL_MSG_TIMESTAMP + " DESC";

        Cursor cursor = db.rawQuery(query, new String[] {
                String.valueOf(userId), String.valueOf(userId),
                String.valueOf(userId),
                String.valueOf(userId)
        });

        if (cursor.moveToFirst()) {
            do {
                Message msg = new Message();
                msg.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_MSG_ID)));
                msg.setSenderId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_MSG_SENDER_ID)));
                msg.setReceiverId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_MSG_RECEIVER_ID)));
                msg.setMessageText(cursor.getString(cursor.getColumnIndexOrThrow(COL_MSG_TEXT)));
                msg.setTimestamp(cursor.getString(cursor.getColumnIndexOrThrow(COL_MSG_TIMESTAMP)));
                msg.setRead(cursor.getInt(cursor.getColumnIndexOrThrow(COL_MSG_READ)) == 1);

                // Hack: store the "Other User's Name" in senderName for display in Inbox
                msg.setSenderName(cursor.getString(cursor.getColumnIndexOrThrow(COL_FULL_NAME)));

                conversations.add(msg);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return conversations;
    }
}
