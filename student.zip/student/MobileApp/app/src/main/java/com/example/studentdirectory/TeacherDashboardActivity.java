package com.example.studentdirectory;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class TeacherDashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_dashboard);

        TextView tvWelcome = findViewById(R.id.tvTeacherWelcome);
        CardView btnMessages = findViewById(R.id.btnTeacherMessages);
        CardView btnEditProfile = findViewById(R.id.btnEditProfile);
        CardView btnDirectory = findViewById(R.id.btnViewDirectory);
        Button btnLogout = findViewById(R.id.btnTeacherLogout);

        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        String fullName = prefs.getString("full_name", "Teacher");
        tvWelcome.setText("Welcome, " + fullName);

        btnMessages
                .setOnClickListener(v -> startActivity(new Intent(TeacherDashboardActivity.this, InboxActivity.class)));

        btnEditProfile.setOnClickListener(v -> {
            startActivity(new Intent(TeacherDashboardActivity.this, EditProfileActivity.class));
        });

        btnDirectory.setOnClickListener(
                v -> startActivity(new Intent(TeacherDashboardActivity.this, StaffDirectoryActivity.class)));

        btnLogout.setOnClickListener(v -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear();
            editor.apply();
            startActivity(new Intent(TeacherDashboardActivity.this, PublicDirectoryActivity.class));
            finish();
        });
    }
}
