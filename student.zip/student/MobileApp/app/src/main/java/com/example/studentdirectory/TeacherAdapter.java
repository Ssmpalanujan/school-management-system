package com.example.studentdirectory;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studentdirectory.models.Teacher;

import java.util.List;

public class TeacherAdapter extends RecyclerView.Adapter<TeacherAdapter.TeacherViewHolder> {

    private Context context;
    private List<Teacher> teacherList;
    private boolean isAdmin; // To distinguish click actions if needed

    public TeacherAdapter(Context context, List<Teacher> teacherList, boolean isAdmin) {
        this.context = context;
        this.teacherList = teacherList;
        this.isAdmin = isAdmin;
    }

    @NonNull
    @Override
    public TeacherViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_teacher, parent, false);
        return new TeacherViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TeacherViewHolder holder, int position) {
        Teacher teacher = teacherList.get(position);
        holder.tvName.setText(teacher.getName());
        holder.tvSubjects.setText(teacher.getSubjects());
        holder.tvEmail.setText(teacher.getEmail());

        holder.itemView.setOnClickListener(v -> {
            if (isAdmin) {
                // Open Edit/View for Admin (For now just View details)
                Intent intent = new Intent(context, TeacherDetailActivity.class); // Or AdminAddEditTeacherActivity
                intent.putExtra("teacher_id", teacher.getId());
                intent.putExtra("is_admin", true);
                context.startActivity(intent);
            } else {
                // Open Public View
                Intent intent = new Intent(context, TeacherDetailActivity.class);
                intent.putExtra("teacher_id", teacher.getId());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return teacherList.size();
    }

    public static class TeacherViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvSubjects, tvEmail;

        public TeacherViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvTeacherName);
            tvSubjects = itemView.findViewById(R.id.tvTeacherSubjects);
            tvEmail = itemView.findViewById(R.id.tvTeacherEmail);
        }
    }

    public void updateList(List<Teacher> newList) {
        teacherList = newList;
        notifyDataSetChanged();
    }
}
