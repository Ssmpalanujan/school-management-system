package com.example.studentdirectory;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studentdirectory.db.DatabaseHelper;
import com.example.studentdirectory.models.Teacher;

import java.util.List;

public class StaffDirectoryActivity extends AppCompatActivity {

    private RecyclerView rvStaff;
    private DatabaseHelper dbHelper;
    private TeacherAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_directory);

        dbHelper = new DatabaseHelper(this);
        rvStaff = findViewById(R.id.rvStaff);
        rvStaff.setLayoutManager(new LinearLayoutManager(this));

        loadTeachers();
    }

    private void loadTeachers() {
        List<Teacher> teacherList = dbHelper.getAllTeachers();
        // isAdmin = false because this is public directory
        adapter = new TeacherAdapter(this, teacherList, false);
        rvStaff.setAdapter(adapter);
    }
}
