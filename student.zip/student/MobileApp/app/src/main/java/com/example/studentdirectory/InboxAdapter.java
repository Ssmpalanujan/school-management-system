package com.example.studentdirectory;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studentdirectory.models.Message;

import java.util.List;

public class InboxAdapter extends RecyclerView.Adapter<InboxAdapter.InboxViewHolder> {

    private Context context;
    private List<Message> conversationList;
    private int currentUserId;

    public InboxAdapter(Context context, List<Message> conversationList, int currentUserId) {
        this.context = context;
        this.conversationList = conversationList;
        this.currentUserId = currentUserId;
    }

    @NonNull
    @Override
    public InboxViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_inbox, parent, false);
        return new InboxViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InboxViewHolder holder, int position) {
        Message msg = conversationList.get(position);

        holder.tvName.setText(msg.getSenderName()); // In DB helper we stored the "Other User's Name" here
        holder.tvSnippet.setText(msg.getMessageText());
        holder.tvTime.setText(msg.getTimestamp()); // Should format this nicely

        String initial = msg.getSenderName().length() > 0 ? msg.getSenderName().substring(0, 1) : "?";
        holder.tvInitial.setText(initial);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ChatActivity.class);
            // We need to determine the 'other' user ID.
            // The query handles fetching messages involving current user.
            // If sender == current, then other is receiver.
            // If sender != current, then other is sender.
            int otherId = (msg.getSenderId() == currentUserId) ? msg.getReceiverId() : msg.getSenderId();

            intent.putExtra("receiver_id", otherId);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return conversationList.size();
    }

    public static class InboxViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvSnippet, tvTime, tvInitial;

        public InboxViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvInboxName);
            tvSnippet = itemView.findViewById(R.id.tvInboxSnippet);
            tvTime = itemView.findViewById(R.id.tvInboxTime);
            tvInitial = itemView.findViewById(R.id.tvInboxInitial);
        }
    }
}
