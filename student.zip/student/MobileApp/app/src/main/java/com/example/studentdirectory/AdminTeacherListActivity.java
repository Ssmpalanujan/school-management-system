package com.example.studentdirectory;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studentdirectory.db.DatabaseHelper;
import com.example.studentdirectory.models.Teacher;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class AdminTeacherListActivity extends AppCompatActivity {

    private RecyclerView rvTeachers;
    private FloatingActionButton fabAddTeacher;
    private DatabaseHelper dbHelper;
    private TeacherAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_teacher_list);

        dbHelper = new DatabaseHelper(this);
        rvTeachers = findViewById(R.id.rvTeachers);
        fabAddTeacher = findViewById(R.id.fabAddTeacher);

        rvTeachers.setLayoutManager(new LinearLayoutManager(this));

        loadTeachers();

        fabAddTeacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminTeacherListActivity.this, AdminAddTeacherActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadTeachers();
    }

    private void loadTeachers() {
        List<Teacher> teacherList = dbHelper.getAllTeachers();
        adapter = new TeacherAdapter(this, teacherList, true);
        rvTeachers.setAdapter(adapter);
    }
}
