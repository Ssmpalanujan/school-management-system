package com.example.studentdirectory;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studentdirectory.db.DatabaseHelper;
import com.example.studentdirectory.models.Message;

import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity {

    private RecyclerView rvMessages;
    private EditText etMessage;
    private ImageButton btnSend;
    private TextView tvChatTitle;
    private DatabaseHelper dbHelper;
    private MessageAdapter adapter;
    private List<Message> messageList;
    private int currentUserId;
    private int receiverId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        dbHelper = new DatabaseHelper(this);
        rvMessages = findViewById(R.id.rvMessages);
        etMessage = findViewById(R.id.etMessage);
        btnSend = findViewById(R.id.btnSend);
        tvChatTitle = findViewById(R.id.tvChatTitle);

        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        // Assuming currentUserId is stored in session. If not, we need to fix Login.
        // The seed data puts users in 'users' table.
        // Let's assume on Login we stored 'user_id'.
        // If not, I should check LoginActivity to ensure it's stored.
        // For now, let's assume it IS, or default to -1 (which will fail).
        // Wait, LoginActivity probably stores "username".
        // I need to fetch ID by Username if it's not in Prefs.
        // Or I'll update LoginActivity later.

        // Temporary fix: if user_id is missing, default to studentUserId (from seed
        // which is dynamic? No, seed data is inserted at runtime).
        // I'll assume LoginActivity stores "user_id".
        currentUserId = prefs.getInt("user_id", -1);

        receiverId = getIntent().getIntExtra("receiver_id", -1);

        if (receiverId == -1) {
            Toast.makeText(this, "Invalid Receiver", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Ideally fetch receiver name for title
        // tvChatTitle.setText("Chat");

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        rvMessages.setLayoutManager(layoutManager);

        loadMessages();

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });
    }

    private void loadMessages() {
        if (currentUserId == -1) {
            // Try to recover user_id if we only have username
            SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
            String username = prefs.getString("username", null);
            if (username != null) {
                // I need a method `getUserIdByUsername` or similar.
                // Or I can add `user_id` to LoginActivity logic.
                // For now, if failed, show error.
                Toast.makeText(this, "Session Error. Please Login Again.", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
        }

        messageList = dbHelper.getMessages(currentUserId, receiverId);
        adapter = new MessageAdapter(this, messageList, currentUserId);
        rvMessages.setAdapter(adapter);
    }

    private void sendMessage() {
        String text = etMessage.getText().toString().trim();
        if (TextUtils.isEmpty(text))
            return;

        dbHelper.sendMessage(currentUserId, receiverId, text);
        etMessage.setText("");
        loadMessages();
        rvMessages.smoothScrollToPosition(messageList.size() - 1);
    }
}
