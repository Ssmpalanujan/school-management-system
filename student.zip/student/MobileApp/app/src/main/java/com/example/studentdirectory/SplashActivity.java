package com.example.studentdirectory;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Delay for 2 seconds then move to main activity (or login check)
        new Handler().postDelayed(() -> {
            // Ideally check for session here, but for now just go to LoginActivity.
            // Wait, per plan we might go to Login OR Main.
            // Let's go to LoginActivity first, which will route to Main if logged in (once
            // we update it).
            // Actually, `LoginActivity` is the launcher currently.
            // We'll update Manifest to make SplashLauncher.

            startActivity(new Intent(SplashActivity.this, LoginActivity.class));
            finish();
        }, 2000);
    }
}
