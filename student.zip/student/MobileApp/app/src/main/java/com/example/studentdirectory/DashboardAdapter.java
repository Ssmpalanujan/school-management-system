package com.example.studentdirectory;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DashboardAdapter extends RecyclerView.Adapter<DashboardAdapter.DashboardViewHolder> {

    private Context context;
    private List<DashboardItem> itemList;

    public DashboardAdapter(Context context, List<DashboardItem> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public DashboardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_dashboard_menu, parent, false);
        return new DashboardViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DashboardViewHolder holder, int position) {
        DashboardItem item = itemList.get(position);
        holder.tvTitle.setText(item.title);
        holder.ivIcon.setImageResource(item.iconResId);

        holder.itemView.setOnClickListener(v -> {
            // Handle Navigation Logic based on Title or ID
            switch (item.title) {
                case "Students":
                    // Only admin can manage, or public view?
                    // Let's link to Public Directory if student, or Admin List if Admin.
                    // Since this is a generic dashboard, we might need role checks or just shared
                    // intents.
                    // For now, let's link to Staff Directory as "Teachers"
                    Toast.makeText(context, "Students: Feature in progress", Toast.LENGTH_SHORT).show();
                    break;
                case "Teachers":
                    context.startActivity(new Intent(context, StaffDirectoryActivity.class));
                    break;
                case "Inbox":
                    context.startActivity(new Intent(context, InboxActivity.class));
                    break;
                case "Attendance":
                case "Syllabus":
                case "Time Table":
                case "Assignments":
                case "Exams":
                case "Results":
                case "Fees":
                case "Events":
                case "Ask Doubt":
                    Toast.makeText(context, item.title + " Coming Soon", Toast.LENGTH_SHORT).show();
                    break;
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class DashboardViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle;
        ImageView ivIcon;

        public DashboardViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvDashboardTitle);
            ivIcon = itemView.findViewById(R.id.ivDashboardIcon);
        }
    }

    public static class DashboardItem {
        String title;
        int iconResId;

        public DashboardItem(String title, int iconResId) {
            this.title = title;
            this.iconResId = iconResId;
        }
    }
}
