package com.example.studentdirectory.models;

public class Teacher {
    private int id;
    private int userId;
    private String name; // Helper field from User table if needed, or fetched via join
    private String subjects;
    private String qualification;
    private String bio;
    private String contactNumber;
    private String email;

    public Teacher() {
    }

    public Teacher(int id, int userId, String name, String subjects, String qualification, String bio,
            String contactNumber, String email) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.subjects = subjects;
        this.qualification = qualification;
        this.bio = bio;
        this.contactNumber = contactNumber;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubjects() {
        return subjects;
    }

    public void setSubjects(String subjects) {
        this.subjects = subjects;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
