package com.example.studentdirectory;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvDashboard;
    private TextView tvUsername;
    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvDashboard = findViewById(R.id.rvDashboardGrid);
        tvUsername = findViewById(R.id.tvDashboardUsername);
        bottomNav = findViewById(R.id.bottomNavigation);

        // Load User Info
        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        String fullName = prefs.getString("full_name", "Guest");
        tvUsername.setText(fullName);

        // Setup Grid
        setupDashboardGrid();

        // Setup Bottom Nav
        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.nav_home) {
                    // Already here
                    return true;
                } else if (itemId == R.id.nav_messages) {
                    startActivity(new Intent(MainActivity.this, InboxActivity.class));
                    return true;
                } else if (itemId == R.id.nav_profile) {
                    // Decide where to go based on role
                    String role = prefs.getString("role", "student");
                    if ("teacher".equals(role)) {
                        startActivity(new Intent(MainActivity.this, TeacherDashboardActivity.class));
                    } else if ("admin".equals(role)) {
                        startActivity(new Intent(MainActivity.this, AdminDashboardActivity.class));
                    } else {
                        // Student Profile (Not implemented yet, maybe just generic)
                    }
                    return true;
                }
                return false;
            }
        });
    }

    private void setupDashboardGrid() {
        List<DashboardAdapter.DashboardItem> items = new ArrayList<>();
        // Using standard android icons as placeholders for now
        items.add(new DashboardAdapter.DashboardItem("Students", android.R.drawable.ic_menu_my_calendar)); // Placeholder
                                                                                                           // icon
        items.add(new DashboardAdapter.DashboardItem("Teachers", android.R.drawable.ic_menu_my_calendar));
        items.add(new DashboardAdapter.DashboardItem("Attendance", android.R.drawable.ic_menu_agenda));
        items.add(new DashboardAdapter.DashboardItem("Syllabus", android.R.drawable.ic_menu_compass));
        items.add(new DashboardAdapter.DashboardItem("Time Table", android.R.drawable.ic_menu_recent_history));
        items.add(new DashboardAdapter.DashboardItem("Assignments", android.R.drawable.ic_menu_edit));
        items.add(new DashboardAdapter.DashboardItem("Exams", android.R.drawable.ic_menu_agenda));
        items.add(new DashboardAdapter.DashboardItem("Results", android.R.drawable.ic_menu_sort_by_size));
        items.add(new DashboardAdapter.DashboardItem("Fees", android.R.drawable.ic_menu_manage));
        items.add(new DashboardAdapter.DashboardItem("Events", android.R.drawable.ic_menu_today));
        items.add(new DashboardAdapter.DashboardItem("Inbox", android.R.drawable.ic_dialog_email));
        items.add(new DashboardAdapter.DashboardItem("Ask Doubt", android.R.drawable.ic_menu_help));

        DashboardAdapter adapter = new DashboardAdapter(this, items);
        // Grid 3 columns
        rvDashboard.setLayoutManager(new GridLayoutManager(this, 3));
        rvDashboard.setAdapter(adapter);
    }

    // Disable back button to prevent going back to Splash/Login loop easily if
    // wanted
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        // Maybe minimize app?
    }
}
