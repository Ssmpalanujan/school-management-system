package com.example.studentdirectory;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studentdirectory.db.DatabaseHelper;
import com.example.studentdirectory.models.Message;

import java.util.List;

public class InboxActivity extends AppCompatActivity {

    private RecyclerView rvInbox;
    private DatabaseHelper dbHelper;
    private InboxAdapter adapter;
    private int currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inbox);

        dbHelper = new DatabaseHelper(this);
        rvInbox = findViewById(R.id.rvInbox);
        rvInbox.setLayoutManager(new LinearLayoutManager(this));

        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        currentUserId = prefs.getInt("user_id", -1);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (currentUserId != -1) {
            loadConversations();
        }
    }

    private void loadConversations() {
        List<Message> conversations = dbHelper.getConversations(currentUserId);
        adapter = new InboxAdapter(this, conversations, currentUserId);
        rvInbox.setAdapter(adapter);
    }
}
