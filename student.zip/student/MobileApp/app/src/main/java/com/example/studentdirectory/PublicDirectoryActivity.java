package com.example.studentdirectory;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.studentdirectory.db.DatabaseHelper;
import com.example.studentdirectory.models.Student;

import java.util.ArrayList;
import java.util.List;

public class PublicDirectoryActivity extends AppCompatActivity {

    private RecyclerView rvStudents;
    private StudentAdapter adapter;
    private List<Student> studentList;
    private DatabaseHelper dbHelper;

    private EditText etSearch;
    private Spinner spinnerGrade;
    private Button btnSearch, btnGoLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_public_directory);

        dbHelper = new DatabaseHelper(this);
        studentList = new ArrayList<>();

        rvStudents = findViewById(R.id.rvStudents);
        etSearch = findViewById(R.id.etSearch);
        spinnerGrade = findViewById(R.id.spinnerGrade);
        btnSearch = findViewById(R.id.btnSearch);
        btnGoLogin = findViewById(R.id.btnGoLogin);

        rvStudents.setLayoutManager(new LinearLayoutManager(this));
        adapter = new StudentAdapter(this, studentList);
        rvStudents.setAdapter(adapter);

        // Setup Spinner
        String[] grades = { "All Grades", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13" };
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                grades);
        spinnerGrade.setAdapter(spinnerAdapter);

        loadStudents(null, null);

        btnSearch.setOnClickListener(v -> {
            String query = etSearch.getText().toString().trim();
            String grade = spinnerGrade.getSelectedItem().toString();
            if (grade.equals("All Grades"))
                grade = null;
            loadStudents(query, grade);
        });

        btnGoLogin.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
        });
    }

    private void loadStudents(String query, String grade) {
        studentList.clear();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String selection = DatabaseHelper.COL_STATUS + "='Active'";
        List<String> args = new ArrayList<>();

        if (query != null && !query.isEmpty()) {
            selection += " AND (" + DatabaseHelper.COL_NAME_INITIALS + " LIKE ? OR " + DatabaseHelper.COL_ADMISSION_NO
                    + " LIKE ?)";
            args.add("%" + query + "%");
            args.add("%" + query + "%");
        }

        if (grade != null) {
            selection += " AND " + DatabaseHelper.COL_GRADE + "=?";
            args.add(grade);
        }

        // Log query only for debug (optional)

        Cursor cursor = db.query(DatabaseHelper.TABLE_STUDENTS, null, selection, args.toArray(new String[0]), null,
                null, DatabaseHelper.COL_GRADE + " ASC, " + DatabaseHelper.COL_CLASS + " ASC");

        if (cursor != null && cursor.moveToFirst()) {
            do {
                studentList.add(new Student(
                        cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_STUDENT_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ADMISSION_NO)),
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_NAME_INITIALS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_FULL_NAME_STUDENT)),
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_GENDER)),
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_GRADE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_CLASS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ADDRESS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_PARENT_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_PARENT_CONTACT)),
                        cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_STATUS))));
            } while (cursor.moveToNext());
            cursor.close();
        }
        adapter.notifyDataSetChanged();
    }
}
